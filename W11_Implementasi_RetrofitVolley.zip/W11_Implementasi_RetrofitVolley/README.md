Nama : Brianti Bella Prasnitia

NIM : E41202408

Prodi : Teknik Informatika

Gol : TIF D

TUGAS Workshop Mobile Applications MINGGU 11 (Implementasi Retrofit/Volley)